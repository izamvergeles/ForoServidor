<?php $__env->startSection('modalContent'); ?>
<div class="modal fade" id="modalDelete" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm Delete</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <p>Confirm delete <span id="deletePost"></span>?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <form id="modalDeleteResourceForm" action="" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <input type="submit" class="btn btn-primary" value="Delete Post"/>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row" style="margin-top: 8px;">
        <table class="table bg-info ml-5 mr-5">
            <thead class="thead-dark">
                <tr>
                    <th scope="col"># id</th>
                    <th scope="col">Post</th>
                    <th scope="col">Delete</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Show</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($post->idusuario == $user->id): ?>
                    <tr>
                        <td>
                            <?php echo e($post->id); ?>

                        </td>
                        <td>
                            <?php echo e($post->mensaje); ?>

                        </td>
                        <?php if($post->updated_at > $now): ?>
                        <td>
                            <a href="javascript: void(0);" 
                                   data-name="<?php echo e($post->id); ?>"
                                   data-url="<?php echo e(url('mypost/' . $post->id)); ?>"
                                   data-toggle="modal"
                                   class="text-danger"
                                   data-target="#modalDelete">Delete</a>
                        </td>
                        
                            <td>
                                <a href="<?php echo e(url('mypost/' . $post->id . '/edit')); ?>" class="text-warning">Edit</a>
                            </td>
                            <?php else: ?>
                            <td>
                                <a class="text-muted">Delete</a>
                            </td>
                            <td>
                                <a class="text-muted">Edit</a>
                            </td>
                        <?php endif; ?>
                        <td>
                            <a href="<?php echo e(url('mypost/' . $post->id)); ?>" class="text-white">Show</a>
                        </td>
                        <?php endif; ?>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="row ml-5">
        <a href="<?php echo e(url('mypost/create')); ?>" class="btn btn-success">New Post</a>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(url('assets/js/product-modal-delete.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/examen/resources/views/post/index.blade.php ENDPATH**/ ?>