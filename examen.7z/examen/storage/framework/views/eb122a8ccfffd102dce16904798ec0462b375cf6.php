<?php $__env->startSection('content'); ?>
    <div class="row" style="margin-top: 8px;">
        <table class="table bg-info ml-5 mr-5">
            <thead class="thead-dark">
                <tr>
                    <th scope="col"># id</th>
                    <th scope="col">Post</th>
                    <th scope="col">Show</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($post->id); ?>

                        </td>
                        <td>
                            <?php echo e($post->mensaje); ?>

                        </td> 
                        <td>
                            <a href="<?php echo e(url('mypost/' . $post->id)); ?>" class="text-white">Show</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="row ml-5">
        <a href="<?php echo e(url('mypost/create')); ?>" class="btn btn-success">New Post</a>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/examen/resources/views/post/all.blade.php ENDPATH**/ ?>