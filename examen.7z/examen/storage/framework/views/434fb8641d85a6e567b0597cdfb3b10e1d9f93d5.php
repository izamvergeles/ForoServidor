<?php $__env->startSection('content'); ?>
<form method="POST">
    <?php echo csrf_field(); ?>
    <?php if(session()->has('user')): ?>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary ml-4 mt-3">Logout</a>
    <?php else: ?>
    <label class="text-white ml-4 mt-5">Email address</label>
    <label>
        <input name="email" class="form-control w-50 ml-4" placeholder="Enter your email">
    </label>
    <button href="<?php echo e(action([App\Http\Controllers\MainController::class, 'login'])); ?>" type="submit" class="btn btn-primary ml-4 mt-3">Submit</button>
</form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/examen/resources/views/login/login.blade.php ENDPATH**/ ?>