<?php $__env->startSection('modalContent'); ?>
<div class="modal fade" id="modalDelete" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm Delete</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <p>Confirm delete <span id="deleteComment"></span>?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <form id="modalDeleteResourceForm" action="" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <input type="submit" class="btn btn-primary" value="Delete Comment"/>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row" style="margin-top: 8px;">
        <table class="table bg-info ml-5 mr-5">
            <thead class="thead-dark">
                <tr>
                    <th scope="col"># id</th>
                    <th scope="col">Comment</th>
                    <th scope="col">Delete</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Show</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($comment->idusuario == $user->id): ?>
                    <tr>
                        <td>
                            <?php echo e($comment->id); ?>

                        </td>
                        <td>
                            <?php echo e($comment->mensaje); ?>

                        </td>
                        <?php if($comment->updated_at > $now): ?>
                        <td>
                            <a href="javascript: void(0);" 
                                   data-name="<?php echo e($comment->id); ?>"
                                   data-url="<?php echo e(url('mycomment/' . $comment->id)); ?>"
                                   data-toggle="modal"
                                   class="text-danger"
                                   data-target="#modalDelete">Delete</a>
                        </td>
                        
                            <td>
                                <a href="<?php echo e(url('mycomment/' . $comment->id . '/edit')); ?>" class="text-warning">Edit</a>
                            </td>
                            <?php else: ?>
                            <td>
                                <a class="text-muted">Delete</a>
                            </td>
                            <td>
                                <a class="text-muted">Edit</a>
                            </td>
                        <?php endif; ?>
                        <td>
                            <a href="<?php echo e(url('mycomment/' . $comment->id)); ?>" class="text-white">Show</a>
                        </td>
                        <?php endif; ?>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(url('assets/js/product-modal-delete2.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/examen/resources/views/comment/index.blade.php ENDPATH**/ ?>