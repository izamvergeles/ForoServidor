<?php $__env->startSection('content'); ?>
<label class="ml-5 mt-5 text-white" style="font-size:20px;">Message:</label>
<div class="ml-5 w-75 bg-white" style="border-radius:10px;">
    
    <div class="w-50 text-dark bg-white ml-2" style="font-size:20px;">
         <?php echo e($post->mensaje); ?>

    </div>
    <div class="text-muted bg-white text-right mr-2" style="font-size:12px;">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->id == $post->idusuario): ?>
                <?php echo e($user->nombre); ?>

            <?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="text-muted bg-white text-right mr-2" style="font-size:12px;">
        Created date: <?php echo e($post->created_at); ?>

    </div>
    <div class="text-muted bg-white text-right mr-2" style="font-size:12px;">
        Update date: <?php echo e($post->updated_at); ?>

    </div>
</div>
<label class="ml-5 mt-5 text-white" style="font-size:20px;">Comments:</label>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($comment->idpost == $post->id): ?>
        <div class="ml-5 w-75 bg-white mt-2" style="border-radius:10px;">
            
            <div class="w-50 text-dark bg-white ml-2" style="font-size:20px;">
                 <?php echo e($comment->mensaje); ?>

            </div>
            <div class="text-muted bg-white text-right mr-2" style="font-size:12px;">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->id == $comment->idusuario): ?>
                        <?php echo e($user->nombre); ?>

                    <?php endif; ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
            <div class="text-muted bg-white text-right mr-2" style="font-size:12px;">
                Created date: <?php echo e($comment->created_at); ?>

            </div>
            <div class="text-muted bg-white text-right mr-2" style="font-size:12px;">
                Update date: <?php echo e($comment->updated_at); ?>

            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div>
        <form action="<?php echo e(url('mycomment')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="mensaje" class="text-white ml-5 mt-5">Comment</label>
                <input value="<?php echo e(old('comment')); ?>" _required type="text" maxlength="100" class="form-control w-50 ml-5 h-25" id="mensaje" name="mensaje" placeholder="Your comment">
                <input name="idpost" type="hidden" value="<?php echo e($post->id); ?>">
                <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger ml-5 w-50"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button type="submit" class="btn btn-success ml-5 mt-3">Add Comment</button>
            </div>
        </form>
    </div>
    <div class="mt-5 ml-5">
        <a href="<?php echo e(url('mypost')); ?>" class="btn btn-primary">Back</a>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/examen/resources/views/post/show.blade.php ENDPATH**/ ?>