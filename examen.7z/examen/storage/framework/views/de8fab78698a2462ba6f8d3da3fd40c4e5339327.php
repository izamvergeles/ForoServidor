    <?php $__env->startSection('content'); ?>
    <div>
        <form action="<?php echo e(url('mycomment')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="mensaje" class="text-white ml-4 mt-5">Comment</label>
                <input value="<?php echo e(old('comment')); ?>" _required type="text" maxlength="100" class="form-control w-50 ml-4 h-25" id="comment" name="comment" placeholder="Your comment">
                <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger ml-4 w-50"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button type="submit" class="btn btn-success ml-4 mt-3">Add</button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary ml-4 mt-3">Back</a>
            </div>
        </form>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/examen/resources/views/comment/create.blade.php ENDPATH**/ ?>